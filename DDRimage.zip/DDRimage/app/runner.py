"""Run converted notebook scripts with UI supplied first-cell parameters."""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from pathlib import Path


APP_DIR = Path(__file__).resolve().parent
ANALYSIS_DIR = APP_DIR / "analysis"


def _literal(value):
    if isinstance(value, dict) and value.get("__path__") is not None:
        return f"Path({value['__path__']!r})"
    if isinstance(value, dict) and value.get("__tuple__") is not None:
        return repr(tuple(value["__tuple__"]))
    return repr(value)


def run_script(filename: str, overrides: dict) -> None:
    path = (ANALYSIS_DIR / filename).resolve()
    if path.parent != ANALYSIS_DIR.resolve() or not path.is_file():
        raise ValueError(f"无效的分析脚本：{filename}")

    source = path.read_text(encoding="utf-8")
    marker = "# %% [cell 1]"
    if marker not in source:
        raise ValueError(f"{filename} 缺少参数单元标记")
    injected = ["\n# ===== DDRimage UI parameters ====="]
    injected.extend(f"{name} = {_literal(value)}" for name, value in overrides.items())
    injected.append("# ===== End UI parameters =====\n")
    source = source.replace(marker, marker + "\n" + "\n".join(injected), 1)

    namespace = {
        "__name__": "__main__",
        "__file__": str(path),
        "__package__": None,
    }
    print(f"\n{'=' * 72}\n开始：{filename}\n{'=' * 72}", flush=True)
    exec(compile(source, str(path), "exec"), namespace, namespace)
    print(f"完成：{filename}", flush=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    payload = json.loads(args.config.read_text(encoding="utf-8"))
    jobs = payload.get("jobs", [])
    if not jobs:
        raise ValueError("没有选择要运行的步骤")

    os.environ.setdefault("MPLBACKEND", "Agg")
    os.environ.setdefault("PYTHONUTF8", "1")
    for index, job in enumerate(jobs, 1):
        print(f"\n步骤 {index}/{len(jobs)}", flush=True)
        run_script(job["script"], job.get("overrides", {}))
    print("\n全部步骤已完成。", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
