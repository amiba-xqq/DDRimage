using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace DDRimageLauncher
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            string root = AppDomain.CurrentDomain.BaseDirectory;
            string bootstrap = Path.Combine(root, "bootstrap.ps1");
            if (!File.Exists(bootstrap))
            {
                MessageBox.Show("找不到 bootstrap.ps1。请完整解压 DDRimage 文件夹后再运行。",
                    "DDRimage", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var info = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File \"" + bootstrap + "\"",
                    WorkingDirectory = root,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };
                using (var process = Process.Start(info))
                {
                    process.WaitForExit();
                    if (process.ExitCode != 0)
                    {
                        MessageBox.Show("DDRimage 未能启动。请检查网络，或双击“验证环境.cmd”查看详细信息。",
                            "DDRimage", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("启动失败：" + ex.Message, "DDRimage",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
