@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0bootstrap.ps1"
if errorlevel 1 (
  echo DDRimage failed to start. Please check your network and try again.
  pause
)
endlocal
