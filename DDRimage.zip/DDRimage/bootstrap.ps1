﻿param([switch]$NoLaunch)

$ErrorActionPreference = 'Stop'
$appRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$runtimeDir = Join-Path $appRoot 'runtime'
$pythonExe = Join-Path $runtimeDir 'python.exe'
$pythonwExe = Join-Path $runtimeDir 'pythonw.exe'
$dataDir = Join-Path $appRoot 'data'
$logFile = Join-Path $dataDir 'bootstrap.log'
$requirements = Join-Path $appRoot 'requirements.txt'
$readyFile = Join-Path $runtimeDir '.ddrimage-ready'
$pythonVersion = '3.12.10'
$pythonSha256 = '4ACBED6DD1C744B0376E3B1CF57CE906F9DC9E95E68824584C8099A63025A3C3'
$pythonUrls = @(
    "https://mirrors.huaweicloud.com/repository/toolkit/python/$pythonVersion/python-$pythonVersion-embed-amd64.zip",
    "https://www.python.org/ftp/python/$pythonVersion/python-$pythonVersion-embed-amd64.zip"
)
$pipIndex = 'https://mirrors.tuna.tsinghua.edu.cn/pypi/web/simple'
$getPip = Join-Path $appRoot 'tools\get-pip.py'
$getPipSha256 = 'FB24E693BAB954209A063D90953621412CCAD4A500905A726286E038F508DDF6'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = 'DDRimage 首次启动'
$form.ClientSize = New-Object System.Drawing.Size(560, 170)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 249)
$launcherIcon = Join-Path $appRoot 'DDRimage.exe'
if (Test-Path -LiteralPath $launcherIcon) {
    $form.Icon = [System.Drawing.Icon]::ExtractAssociatedIcon($launcherIcon)
}

$title = New-Object System.Windows.Forms.Label
$title.Text = '正在准备本地运行环境'
$title.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 14, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(23, 63, 59)
$title.SetBounds(24, 20, 510, 32)
$form.Controls.Add($title)

$status = New-Object System.Windows.Forms.Label
$status.Text = '检查环境…'
$status.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)
$status.ForeColor = [System.Drawing.Color]::FromArgb(80, 102, 105)
$status.SetBounds(26, 63, 505, 28)
$form.Controls.Add($status)

$progress = New-Object System.Windows.Forms.ProgressBar
$progress.Style = 'Marquee'
$progress.MarqueeAnimationSpeed = 25
$progress.SetBounds(26, 105, 508, 20)
$form.Controls.Add($progress)

$note = New-Object System.Windows.Forms.Label
$note.Text = '首次运行需要联网下载，完成后可直接复用程序文件夹内的环境。'
$note.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 8)
$note.ForeColor = [System.Drawing.Color]::FromArgb(105, 120, 123)
$note.SetBounds(26, 135, 508, 22)
$form.Controls.Add($note)

$form.Show()
[System.Windows.Forms.Application]::DoEvents()

function Set-Status([string]$text) {
    $status.Text = $text
    if (Test-Path -LiteralPath $dataDir) {
        Add-Content -LiteralPath $logFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $text" -Encoding UTF8
    }
    [System.Windows.Forms.Application]::DoEvents()
}

function Get-Sha256([string]$path) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $stream = $null
    try {
        $stream = [System.IO.File]::OpenRead($path)
        return ([System.BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '')
    } finally {
        if ($stream) { $stream.Dispose() }
        $sha.Dispose()
    }
}

function Download-WithFallback([string[]]$urls, [string]$destination) {
    $lastError = $null
    foreach ($url in $urls) {
        try {
            Set-Status "正在下载：$url"
            Invoke-WebRequest -Uri $url -OutFile $destination -UseBasicParsing
            return
        } catch {
            $lastError = $_
            if (Test-Path -LiteralPath $dataDir) {
                Add-Content -LiteralPath $logFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  下载失败：$url；$($_.Exception.Message)" -Encoding UTF8
            }
            if (Test-Path -LiteralPath $destination) { Remove-Item -LiteralPath $destination -Force }
        }
    }
    throw $lastError
}

try {
    New-Item -ItemType Directory -Force -Path $dataDir | Out-Null
    Add-Content -LiteralPath $logFile -Value "`r`n$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  DDRimage 启动检查开始" -Encoding UTF8
    $requirementsHash = Get-Sha256 $requirements
    $ready = (Test-Path -LiteralPath $readyFile) -and
             (Test-Path -LiteralPath $pythonExe) -and
             ((Get-Content -LiteralPath $readyFile -Raw).Trim() -eq $requirementsHash)

    if (-not $ready) {
        if (-not (Test-Path -LiteralPath $pythonExe)) {
            Set-Status '下载 Python 3.12 便携运行环境…'
            $zip = Join-Path $dataDir 'python-runtime.zip'
            Download-WithFallback $pythonUrls $zip
            $actualHash = Get-Sha256 $zip
            if ($actualHash -ne $pythonSha256) {
                throw "Python 下载文件校验失败。期望 $pythonSha256，实际 $actualHash"
            }
            New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
            Expand-Archive -LiteralPath $zip -DestinationPath $runtimeDir -Force
            Remove-Item -LiteralPath $zip -Force

            $pth = Join-Path $runtimeDir 'python312._pth'
            $pthText = Get-Content -LiteralPath $pth -Raw
            $pthText = $pthText -replace '#import site', 'import site'
            if ($pthText -notmatch '(?m)^Lib\\site-packages\s*$') {
                $pthText = $pthText.TrimEnd() + "`r`nLib\site-packages`r`n"
            }
            Set-Content -LiteralPath $pth -Value $pthText -Encoding ASCII
        }

        Set-Status '准备 pip…'
        $savedErrorAction = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        & $pythonExe -c "import pip" 2>$null
        $pipImportExit = $LASTEXITCODE
        $ErrorActionPreference = $savedErrorAction
        if ($pipImportExit -ne 0) {
            if (-not (Test-Path -LiteralPath $getPip) -or
                (Get-Sha256 $getPip) -ne $getPipSha256) {
                throw '程序内置的 pip 引导文件缺失或校验失败'
            }
            $ErrorActionPreference = 'Continue'
            & $pythonExe $getPip --no-warn-script-location --index-url $pipIndex 2>&1 |
                ForEach-Object { Add-Content -LiteralPath $logFile -Value $_.ToString() -Encoding UTF8 }
            $getPipExit = $LASTEXITCODE
            $ErrorActionPreference = $savedErrorAction
            if ($getPipExit -ne 0) { throw "pip 安装失败（退出代码 $getPipExit）" }
        }

        Set-Status '从镜像安装图像分析与界面组件；首次运行可能需要数分钟…'
        $ErrorActionPreference = 'Continue'
        & $pythonExe -m pip install --disable-pip-version-check --no-warn-script-location --prefer-binary --index-url $pipIndex -r $requirements 2>&1 |
            ForEach-Object { Add-Content -LiteralPath $logFile -Value $_.ToString() -Encoding UTF8 }
        $pipInstallExit = $LASTEXITCODE
        $ErrorActionPreference = $savedErrorAction
        if ($pipInstallExit -ne 0) { throw "Python 依赖安装失败（退出代码 $pipInstallExit）" }

        Set-Status '验证运行环境…'
        $ErrorActionPreference = 'Continue'
        & $pythonExe -c "import PySide6,numpy,scipy,pandas,matplotlib,PIL,tifffile,skimage,cv2,liffile; print('DDRimage runtime OK')" 2>&1 |
            ForEach-Object { Add-Content -LiteralPath $logFile -Value $_.ToString() -Encoding UTF8 }
        $runtimeCheckExit = $LASTEXITCODE
        $ErrorActionPreference = $savedErrorAction
        if ($runtimeCheckExit -ne 0) { throw "运行环境验证失败（退出代码 $runtimeCheckExit）" }
        Set-Content -LiteralPath $readyFile -Value $requirementsHash -Encoding ASCII
    }

    Set-Status '环境已就绪，正在启动 DDRimage…'
    Start-Sleep -Milliseconds 350
    $form.Close()
    if (-not $NoLaunch) {
        $mainScript = Join-Path $appRoot 'app\main.py'
        $mainProcess = Start-Process -FilePath $pythonwExe -ArgumentList @("`"$mainScript`"") -WorkingDirectory $appRoot -PassThru
        Start-Sleep -Seconds 1
        $mainProcess.Refresh()
        if ($mainProcess.HasExited) {
            throw "主界面启动失败（退出代码 $($mainProcess.ExitCode)）"
        }
        Add-Content -LiteralPath $logFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  主界面已启动，PID=$($mainProcess.Id)" -Encoding UTF8
    }
    exit 0
} catch {
    if (Test-Path -LiteralPath $dataDir) {
        Add-Content -LiteralPath $logFile -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  失败：$($_.Exception.ToString())" -Encoding UTF8
    }
    $progress.Style = 'Blocks'
    $progress.Value = 0
    $status.Text = '环境准备失败'
    $note.Text = $_.Exception.Message
    [System.Windows.Forms.Application]::DoEvents()
    [System.Windows.Forms.MessageBox]::Show(
        "DDRimage 无法完成首次启动。`r`n`r`n$($_.Exception.Message)`r`n`r`n请检查网络后重新双击启动程序。",
        'DDRimage', 'OK', 'Error') | Out-Null
    $form.Close()
    exit 1
}
